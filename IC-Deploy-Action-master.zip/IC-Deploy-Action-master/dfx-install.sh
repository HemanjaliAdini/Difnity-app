#!/bin/sh -l
echo y | sh -ci "$(curl -fsSL https://sdk.dfinity.org/install.sh)"
